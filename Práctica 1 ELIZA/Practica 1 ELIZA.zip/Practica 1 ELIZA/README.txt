Practica 1 ELIZA

Implementación de chatbot ELIZA en Perl
Tiene integradas diferentes respuestas posibles, sin embargo no abarca aún un léxico grande, en caso de que pregunte si quieres agregar una respuesta SOLO escribir la respuesta que quieres que ELIZA te diga en un futuro, es posible usar emojis, mayusculas y/o acentos. Si la respuesta no desea ser guardada solo escribir "no" y seguir conversando de manera normal.
El programa escribe las respuestas dadas por el usuario en ELIZA.txt que se encuentra en la misma carpeta, tiene alguna respuestas predefinidas como "Qué hora es" o "Por qué crees que" usando el formato dado por el profesor que es /mensaje1/mensaje2/s. 